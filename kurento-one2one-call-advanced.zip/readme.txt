This archive includes kurento application server for power project signalling.
