/*
 * (C) Copyright 2014 Kurento (http://kurento.org/)
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 *
 */

package org.kurento.tutorial.one2onecalladv;

import org.kurento.client.KurentoClient;
import org.kurento.tutorial.one2onecalladv.kmsmonitor.KmsMonitor;
import org.kurento.tutorial.one2onecalladv.kmsmonitor.KmsStats;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.context.annotation.Bean;
import org.springframework.web.socket.config.annotation.EnableWebSocket;
import org.springframework.web.socket.config.annotation.WebSocketConfigurer;
import org.springframework.web.socket.config.annotation.WebSocketHandlerRegistry;

import javax.print.attribute.standard.DateTimeAtCreation;
import java.io.BufferedWriter;
import java.io.File;
import java.io.FileWriter;
import java.io.IOException;
import java.util.Date;

/**
 * Video call 1 to 1 demo (main).
 *
 * @author Boni Garcia (bgarcia@gsyc.es)
 * @author Micael Gallego (micael.gallego@gmail.com)
 * @since 5.0.0
 */
@SpringBootApplication
@EnableWebSocket
public class One2OneCallAdvApp implements WebSocketConfigurer {

  static final String DEFAULT_APP_SERVER_URL = "https://localhost:8443";
  final static String DEFAULT_KMS_WS_URI = "ws://localhost:8888/kurento";
  public static int k = 0;
  private static double outboundRtt;
  private static double outboundDeltaPlis;
  private static double outboundDeltaNecks;
  private static double outbondByteCount;
  private static double outboundTargetBitrate;
  private static double inboundJitter;
  private static double inboundFractionLost;
  private static double inboundDeltaNeck;
  private static double inboundDeltaPlis;
  private static double inboundByteCount;
  private static double inboundPacketLostCount;
  private static String outboundPath = "OutBoundData.txt";
  private static String inboundPath = "InBondData.txt";
  private static long end = 0;
  private static boolean startTrigger = false;

  @Bean
  public CallHandler callHandler() {
    return new CallHandler();
  }

  @Bean
  public UserRegistry registry() {
    return new UserRegistry();
  }

  @Bean
  public KurentoClient kurentoClient() {
    return KurentoClient.create();
  }

  @Override
  public void registerWebSocketHandlers(WebSocketHandlerRegistry registry) {
    registry.addHandler(callHandler(), "/call");
  }

  public static void main(String[] args) throws Exception {
    new SpringApplication(One2OneCallAdvApp.class).run(args);
    KmsMonitor kmsMonitor = new KmsMonitor(System.getProperty("kms.ws.uri", DEFAULT_KMS_WS_URI));

    while (true) {
      // if (startTrigger == true) {
      Date currentDate = new Date();
      System.out.println(currentDate);
      KmsStats kmsStats = kmsMonitor.updateStats();
     outboundRtt = kmsStats.getWebRtcStats().getOutbound().getRtt();
      outboundDeltaPlis = kmsStats.getWebRtcStats().getOutbound().getDeltaPlis();
      outboundDeltaNecks = kmsStats.getWebRtcStats().getOutbound().getDeltaNacks();
      outbondByteCount = kmsStats.getWebRtcStats().getOutbound().getByteCount();
      outboundTargetBitrate = kmsStats.getWebRtcStats().getOutbound().getTargetBitrate();
      inboundJitter = kmsStats.getWebRtcStats().getInbound().getJitter();
      inboundFractionLost = kmsStats.getWebRtcStats().getInbound().getFractionLost();
      inboundDeltaNeck = kmsStats.getWebRtcStats().getInbound().getDeltaNacks();
      inboundDeltaPlis = kmsStats.getWebRtcStats().getInbound().getDeltaPlis();
      inboundByteCount = kmsStats.getWebRtcStats().getInbound().getByteCount();
      inboundPacketLostCount = kmsStats.getWebRtcStats().getInbound().getPacketLostCount();


      if (k == 0) {
        writeUsingBufferedWriter(outboundPath, "currentDate" + ";" + "RTT"
                + ";delta Plis"
                + ";delta Necks"
                + ";byte Count"
                + ";targetBitrate"
                + ";", 1);

        writeUsingBufferedWriter(inboundPath,  "currentDate" + ";" + "Jitter"
                + ";Fraction Lost"
                + ";delta Necks"
                + ";delta Plis"
                + ";byte Count"
                + ";packet Lost"
                + ";", 1);

        k++;
      } if(inboundByteCount>1) {
        appendUsingBufferedWriter(outboundPath, currentDate + ";"  + outboundRtt+ ";"
                +  outboundDeltaPlis + ";"
                + outboundDeltaNecks+ ";"
                +  outbondByteCount+ ";"
                + outboundTargetBitrate
                + ";", 1);
        appendUsingBufferedWriter(inboundPath, currentDate + ";" + + inboundJitter+ ";"
                + inboundFractionLost+ ";"
                + inboundDeltaNeck+ ";"
                +inboundDeltaPlis+ ";"
                + inboundByteCount+ ";"
                + inboundPacketLostCount
                + ";", 1);
      }
      //}
      Thread.sleep(1000);
      if (startTrigger == false && inboundByteCount > 1) {
        end = System.currentTimeMillis() + 20000 * 1000; //first num = num of seconds
        startTrigger = true;
      }

      if (startTrigger == true && System.currentTimeMillis() > end) {
        System.exit(0);
      }
    }

  }


  // обновляем файл с помощью BufferedWriter
  private static void appendUsingBufferedWriter(String filePath, String text, int noOfLines) {
    File file = new File(filePath);
    FileWriter fr = null;
    BufferedWriter br = null;
    try {
      //для обновления файла нужно инициализировать FileWriter с помощью этого конструктора
      fr = new FileWriter(file, true);
      br = new BufferedWriter(fr);
      for (int i = 0; i < noOfLines; i++) {
        br.newLine();
        //теперь мы можем использовать метод write или метод append
        br.write(text);
      }

    } catch (IOException e) {
      e.printStackTrace();
    } finally {
      try {
        br.close();
        fr.close();
      } catch (IOException e) {
        e.printStackTrace();
      }
    }
  }

  // пишем в файл с помощью BufferedWriter
  private static void writeUsingBufferedWriter(String filePath, String data, int noOfLines) {
    File file = new File(filePath);
    FileWriter fr = null;
    BufferedWriter br = null;
    String dataWithNewLine = data + System.getProperty("line.separator");
    try {
      fr = new FileWriter(file);
      br = new BufferedWriter(fr);
      for (int i = noOfLines; i > 0; i--) {
        br.write(dataWithNewLine);
      }
    } catch (IOException e) {
      e.printStackTrace();
    } finally {
      try {
        br.close();
        fr.close();
      } catch (IOException e) {
        e.printStackTrace();
      }
    }
  }
}